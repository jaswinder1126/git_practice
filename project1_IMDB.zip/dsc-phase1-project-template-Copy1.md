# MS_MOVIES_ANALSYS

**Authors:** Jaswinder singh
***

## Overview


THE file contains the crystal view of data from the resouurce IMBD in terms of business, statics, data, methods and recomendations

## Business Problem

Microsoft, the tech company is now jumping into the entertainment industry.
thus, before making a high budget feature film, it is a good practice to analyse data from past and then make right decision.

***

**the company wants to make a movie as a symbol of creating MICROSOFT STUDIOS, thys, the type of fims is really important to stand in the crowd.
**the data used in this project is completely from IMDB, the datasets are the records of popular movies with respect to following aspects: region, director, writer, ratings, votes, language etc. though,, some records are not useful.
**this project analuse the data and create graphs to show information such as: most rated movies, most popular writer, director, highest number of movies by year and so on.
**this information will help the stakeholders to make a right decision about choosing genre of the movie, director for movie, region to release in.
***

## Data Understanding


Questions to consider:
* Where did the data come from, and how do they relate to the data analysis questions?
* Data in this project belongs to IMDB. Dataframes contains information such as release year, writer, director, revenue of the movies.
* What is the target variable?
* Target variables are "popular writer", "popular director", "average ratings". "votes" etc.
* What are the properties of the variables you intend to use?
* The variables are complete strings and integers. It is a good practice to format data with respect to each other in order to make and understand a trend.
***


```python
# Import standard packages
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

%matplotlib inline
```


```python
import gzip
import csv
```


```python
# import files which contains data about rating, titles etc.
df_r=pd.read_csv('imdb.title.ratings.csv.gz')
df_c=pd.read_csv('imdb.title.crew.csv.gz')
df_a=pd.read_csv('imdb.title.akas.csv.gz')
df_b=pd.read_csv('imdb.name.basics.csv.gz')
```


```python
#checking info and a overview of the datasets
df_r.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tconst</th>
      <th>averagerating</th>
      <th>numvotes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>tt10356526</td>
      <td>8.3</td>
      <td>31</td>
    </tr>
    <tr>
      <th>1</th>
      <td>tt10384606</td>
      <td>8.9</td>
      <td>559</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_c.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tconst</th>
      <th>directors</th>
      <th>writers</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>tt0285252</td>
      <td>nm0899854</td>
      <td>nm0899854</td>
    </tr>
    <tr>
      <th>1</th>
      <td>tt0438973</td>
      <td>NaN</td>
      <td>nm0175726,nm1802864</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_a.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>title_id</th>
      <th>ordering</th>
      <th>title</th>
      <th>region</th>
      <th>language</th>
      <th>types</th>
      <th>attributes</th>
      <th>is_original_title</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>tt0369610</td>
      <td>10</td>
      <td>Джурасик свят</td>
      <td>BG</td>
      <td>bg</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>tt0369610</td>
      <td>11</td>
      <td>Jurashikku warudo</td>
      <td>JP</td>
      <td>NaN</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
# changing columns name from title id to tconst
new_df=df_a.rename(columns={'title_id':'tconst'})
```


```python
#all three data sets have one common attribute whihc is title. 
```


```python
#merging all datasets in to one dataset
dfm1=df_r.merge(df_c)
dfm=dfm1.merge(new_df)
```


```python
dfm
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tconst</th>
      <th>averagerating</th>
      <th>numvotes</th>
      <th>directors</th>
      <th>writers</th>
      <th>ordering</th>
      <th>title</th>
      <th>region</th>
      <th>language</th>
      <th>types</th>
      <th>attributes</th>
      <th>is_original_title</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>tt1042974</td>
      <td>6.4</td>
      <td>20</td>
      <td>nm1915232</td>
      <td>nm1915232</td>
      <td>1</td>
      <td>Just Inès</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>tt1042974</td>
      <td>6.4</td>
      <td>20</td>
      <td>nm1915232</td>
      <td>nm1915232</td>
      <td>2</td>
      <td>Samo Ines</td>
      <td>RS</td>
      <td>NaN</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>tt1042974</td>
      <td>6.4</td>
      <td>20</td>
      <td>nm1915232</td>
      <td>nm1915232</td>
      <td>3</td>
      <td>Just Inès</td>
      <td>GB</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>tt1043726</td>
      <td>4.2</td>
      <td>50352</td>
      <td>nm0001317</td>
      <td>nm0393517,nm0316417,nm0001317,nm1048866</td>
      <td>10</td>
      <td>The Legend of Hercules</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>tt1043726</td>
      <td>4.2</td>
      <td>50352</td>
      <td>nm0001317</td>
      <td>nm0393517,nm0316417,nm0001317,nm1048866</td>
      <td>11</td>
      <td>Hércules - A Lenda Começa</td>
      <td>PT</td>
      <td>NaN</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>261801</th>
      <td>tt9691896</td>
      <td>6.3</td>
      <td>21</td>
      <td>nm0663605</td>
      <td>NaN</td>
      <td>4</td>
      <td>Coming Out</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>261802</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>1</td>
      <td>Code Geass: Lelouch of the Rebellion Episode III</td>
      <td>JP</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>261803</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>2</td>
      <td>Code Geass: Lelouch of the Rebellion Episode III</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>261804</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>3</td>
      <td>Code Geass: Lelouch of the Rebellion - Glorifi...</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>261805</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>4</td>
      <td>Code Geass: Lelouch of the Rebellion - Emperor</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>261806 rows × 12 columns</p>
</div>




```python
#checking for duplicate entries
dfm.duplicated().value_counts()
```




    False    261806
    dtype: int64




```python
# filetring movies having average rating more than 7
df_average=dfm.loc[(dfm['averagerating']>7)]
df_average
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tconst</th>
      <th>averagerating</th>
      <th>numvotes</th>
      <th>directors</th>
      <th>writers</th>
      <th>ordering</th>
      <th>title</th>
      <th>region</th>
      <th>language</th>
      <th>types</th>
      <th>attributes</th>
      <th>is_original_title</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>55</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>1</td>
      <td>Silent Sonata</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>56</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>2</td>
      <td>Circus Fantasticus</td>
      <td>SI</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>57</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>3</td>
      <td>Sonata silenciosa</td>
      <td>UY</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original subtitled version</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>58</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>4</td>
      <td>Circus Fantasticus</td>
      <td>FI</td>
      <td>NaN</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>59</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>5</td>
      <td>I sonata tis siopis</td>
      <td>GR</td>
      <td>NaN</td>
      <td>festival</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>261777</th>
      <td>tt9526152</td>
      <td>7.6</td>
      <td>29</td>
      <td>nm1425958</td>
      <td>nm8916539</td>
      <td>6</td>
      <td>Gekijouban danjon ni deai o motomeru no wa mac...</td>
      <td>JP</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>261802</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>1</td>
      <td>Code Geass: Lelouch of the Rebellion Episode III</td>
      <td>JP</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>261803</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>2</td>
      <td>Code Geass: Lelouch of the Rebellion Episode III</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original</td>
      <td>NaN</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>261804</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>3</td>
      <td>Code Geass: Lelouch of the Rebellion - Glorifi...</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
    <tr>
      <th>261805</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>4</td>
      <td>Code Geass: Lelouch of the Rebellion - Emperor</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
      <td>0.0</td>
    </tr>
  </tbody>
</table>
<p>72211 rows × 12 columns</p>
</div>




```python
# now, we will take the title id of directors and writers having most number of movies
# most frequent value in Team
df_average['writers'].value_counts().idxmax()
```




    'nm0604555,nm0860155'




```python
# most frequent value in Team
df_average['directors'].value_counts().idxmax()
```




    'nm0000229'




```python
#dropping column which are not important
final=df_average.drop(['is_original_title'],axis=1)
```


```python
final
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tconst</th>
      <th>averagerating</th>
      <th>numvotes</th>
      <th>directors</th>
      <th>writers</th>
      <th>ordering</th>
      <th>title</th>
      <th>region</th>
      <th>language</th>
      <th>types</th>
      <th>attributes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>55</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>1</td>
      <td>Silent Sonata</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>56</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>2</td>
      <td>Circus Fantasticus</td>
      <td>SI</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>57</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>3</td>
      <td>Sonata silenciosa</td>
      <td>UY</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original subtitled version</td>
    </tr>
    <tr>
      <th>58</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>4</td>
      <td>Circus Fantasticus</td>
      <td>FI</td>
      <td>NaN</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>59</th>
      <td>tt1156528</td>
      <td>7.2</td>
      <td>265</td>
      <td>nm0121203</td>
      <td>nm0121203</td>
      <td>5</td>
      <td>I sonata tis siopis</td>
      <td>GR</td>
      <td>NaN</td>
      <td>festival</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>261777</th>
      <td>tt9526152</td>
      <td>7.6</td>
      <td>29</td>
      <td>nm1425958</td>
      <td>nm8916539</td>
      <td>6</td>
      <td>Gekijouban danjon ni deai o motomeru no wa mac...</td>
      <td>JP</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>261802</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>1</td>
      <td>Code Geass: Lelouch of the Rebellion Episode III</td>
      <td>JP</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>261803</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>2</td>
      <td>Code Geass: Lelouch of the Rebellion Episode III</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>original</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>261804</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>3</td>
      <td>Code Geass: Lelouch of the Rebellion - Glorifi...</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>261805</th>
      <td>tt9844256</td>
      <td>7.5</td>
      <td>24</td>
      <td>nm0849465</td>
      <td>nm0849465,nm1287521</td>
      <td>4</td>
      <td>Code Geass: Lelouch of the Rebellion - Emperor</td>
      <td>XWW</td>
      <td>en</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>72211 rows × 11 columns</p>
</div>




```python
# #now, we will filter the movies which has these writers or directors as crew
crew=final[(final["directors"] == 'nm0000229') | (final["writers"] == "nm0604555,nm0860155")]
crew.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>tconst</th>
      <th>averagerating</th>
      <th>numvotes</th>
      <th>directors</th>
      <th>writers</th>
      <th>ordering</th>
      <th>title</th>
      <th>region</th>
      <th>language</th>
      <th>types</th>
      <th>attributes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4384</th>
      <td>tt0443272</td>
      <td>7.4</td>
      <td>228701</td>
      <td>nm0000229</td>
      <td>nm1065785,nm0329447</td>
      <td>10</td>
      <td>Lincoln</td>
      <td>HR</td>
      <td>NaN</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4385</th>
      <td>tt0443272</td>
      <td>7.4</td>
      <td>228701</td>
      <td>nm0000229</td>
      <td>nm1065785,nm0329447</td>
      <td>11</td>
      <td>Lincoln</td>
      <td>GR</td>
      <td>NaN</td>
      <td>imdbDisplay</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
final.plot(x ='averagerating', y='ordering', kind = 'scatter')

```




    <AxesSubplot:xlabel='averagerating', ylabel='ordering'>




![png](output_21_1.png)



```python
# here we can see that the most orderd movies are the ones whihc are rated arround 8 and 8.5.
# this gives insights that extreme rated movies are not much popular.

```


```python
# so, no we will check the title of the movies having rating arround 8 and 8.5
final.loc[final['directors'] =='nm0000229', ['title']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>title</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>4384</th>
      <td>Lincoln</td>
    </tr>
    <tr>
      <th>4385</th>
      <td>Lincoln</td>
    </tr>
    <tr>
      <th>4386</th>
      <td>Lincoln</td>
    </tr>
    <tr>
      <th>4387</th>
      <td>Lincoln</td>
    </tr>
    <tr>
      <th>4388</th>
      <td>Лiнкольн</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>253805</th>
      <td>War Horse</td>
    </tr>
    <tr>
      <th>253806</th>
      <td>Caballo de guerra</td>
    </tr>
    <tr>
      <th>253807</th>
      <td>Caballo de batalla</td>
    </tr>
    <tr>
      <th>253808</th>
      <td>Gefährten</td>
    </tr>
    <tr>
      <th>253809</th>
      <td>Бойовий кiнь</td>
    </tr>
  </tbody>
</table>
<p>222 rows × 1 columns</p>
</div>




```python
## from above data and internet, it is concluded that Steven Spielberg is a good choice for writer
```


```python
# now, we will check this data set from kaggle
```


```python
df_k=pd.read_csv('archive.zip')
```


```python
# to check the view to dataset
df_k.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Title</th>
      <th>Genre</th>
      <th>Description</th>
      <th>Director</th>
      <th>Actors</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1</td>
      <td>Guardians of the Galaxy</td>
      <td>Action,Adventure,Sci-Fi</td>
      <td>A group of intergalactic criminals are forced ...</td>
      <td>James Gunn</td>
      <td>Chris Pratt, Vin Diesel, Bradley Cooper, Zoe S...</td>
      <td>2014</td>
      <td>121</td>
      <td>8.1</td>
      <td>757074</td>
      <td>333.13</td>
      <td>76.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>2</td>
      <td>Prometheus</td>
      <td>Adventure,Mystery,Sci-Fi</td>
      <td>Following clues to the origin of mankind, a te...</td>
      <td>Ridley Scott</td>
      <td>Noomi Rapace, Logan Marshall-Green, Michael Fa...</td>
      <td>2012</td>
      <td>124</td>
      <td>7.0</td>
      <td>485820</td>
      <td>126.46</td>
      <td>65.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_k.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rank</th>
      <th>Year</th>
      <th>Runtime (Minutes)</th>
      <th>Rating</th>
      <th>Votes</th>
      <th>Revenue (Millions)</th>
      <th>Metascore</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1000.000000</td>
      <td>1.000000e+03</td>
      <td>872.000000</td>
      <td>936.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>500.500000</td>
      <td>2012.783000</td>
      <td>113.172000</td>
      <td>6.723200</td>
      <td>1.698083e+05</td>
      <td>82.956376</td>
      <td>58.985043</td>
    </tr>
    <tr>
      <th>std</th>
      <td>288.819436</td>
      <td>3.205962</td>
      <td>18.810908</td>
      <td>0.945429</td>
      <td>1.887626e+05</td>
      <td>103.253540</td>
      <td>17.194757</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000</td>
      <td>2006.000000</td>
      <td>66.000000</td>
      <td>1.900000</td>
      <td>6.100000e+01</td>
      <td>0.000000</td>
      <td>11.000000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>250.750000</td>
      <td>2010.000000</td>
      <td>100.000000</td>
      <td>6.200000</td>
      <td>3.630900e+04</td>
      <td>13.270000</td>
      <td>47.000000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>500.500000</td>
      <td>2014.000000</td>
      <td>111.000000</td>
      <td>6.800000</td>
      <td>1.107990e+05</td>
      <td>47.985000</td>
      <td>59.500000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>750.250000</td>
      <td>2016.000000</td>
      <td>123.000000</td>
      <td>7.400000</td>
      <td>2.399098e+05</td>
      <td>113.715000</td>
      <td>72.000000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1000.000000</td>
      <td>2016.000000</td>
      <td>191.000000</td>
      <td>9.000000</td>
      <td>1.791916e+06</td>
      <td>936.630000</td>
      <td>100.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#check the columns and create a varribale to for movies over 180mis of runtime
df_k.columns
```




    Index(['Rank', 'Title', 'Genre', 'Description', 'Director', 'Actors', 'Year',
           'Runtime (Minutes)', 'Rating', 'Votes', 'Revenue (Millions)',
           'Metascore'],
          dtype='object')




```python
df_k[df_k['Runtime (Minutes)']>=180]['Title']
```




    82     The Wolf of Wall Street
    88           The Hateful Eight
    311             La vie d'Adèle
    828                 Grindhouse
    965              Inland Empire
    Name: Title, dtype: object




```python
#checking votes for movies with respect to year
df_k.groupby('Year')['Votes'].mean().sort_values(ascending=False)
```




    Year
    2012    285226.093750
    2008    275505.384615
    2006    269289.954545
    2009    255780.647059
    2010    252782.316667
    2007    244331.037736
    2011    240790.301587
    2013    219049.648352
    2014    203930.224490
    2015    115726.220472
    2016     48591.754209
    Name: Votes, dtype: float64




```python
a=df_k['Year']
b=df_k['Votes']
 
# creating the bar plot
fig, ax = plt.subplots(figsize =(7, 7))
ax.barh(a,b)
ax.set_title('most votes movies by year')
ax.set_xlabel('votes')
ax.set_ylabel('years')
```




    Text(0, 0.5, 'years')




![png](output_32_1.png)



```python
#finding movies which are top rated and checking the name of directors
h_r=df_k.nlargest(10,'Rating')[['Title','Rating','Director','Metascore','Runtime (Minutes)']]\
.set_index('Title')
h_r
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Rating</th>
      <th>Director</th>
      <th>Metascore</th>
      <th>Runtime (Minutes)</th>
    </tr>
    <tr>
      <th>Title</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>The Dark Knight</th>
      <td>9.0</td>
      <td>Christopher Nolan</td>
      <td>82.0</td>
      <td>152</td>
    </tr>
    <tr>
      <th>Inception</th>
      <td>8.8</td>
      <td>Christopher Nolan</td>
      <td>74.0</td>
      <td>148</td>
    </tr>
    <tr>
      <th>Dangal</th>
      <td>8.8</td>
      <td>Nitesh Tiwari</td>
      <td>NaN</td>
      <td>161</td>
    </tr>
    <tr>
      <th>Interstellar</th>
      <td>8.6</td>
      <td>Christopher Nolan</td>
      <td>74.0</td>
      <td>169</td>
    </tr>
    <tr>
      <th>Kimi no na wa</th>
      <td>8.6</td>
      <td>Makoto Shinkai</td>
      <td>79.0</td>
      <td>106</td>
    </tr>
    <tr>
      <th>The Intouchables</th>
      <td>8.6</td>
      <td>Olivier Nakache</td>
      <td>57.0</td>
      <td>112</td>
    </tr>
    <tr>
      <th>The Prestige</th>
      <td>8.5</td>
      <td>Christopher Nolan</td>
      <td>66.0</td>
      <td>130</td>
    </tr>
    <tr>
      <th>The Departed</th>
      <td>8.5</td>
      <td>Martin Scorsese</td>
      <td>85.0</td>
      <td>151</td>
    </tr>
    <tr>
      <th>The Dark Knight Rises</th>
      <td>8.5</td>
      <td>Christopher Nolan</td>
      <td>78.0</td>
      <td>164</td>
    </tr>
    <tr>
      <th>Whiplash</th>
      <td>8.5</td>
      <td>Damien Chazelle</td>
      <td>88.0</td>
      <td>107</td>
    </tr>
  </tbody>
</table>
</div>




```python
#visualize the result for better understanding
#importing seaborn library for better graphs
import seaborn as sns

# creating the bar plot
sns.barplot(x='Rating',y=h_r.index,data=h_r,hue='Director')
#the documentation for seaborn library is at https://seaborn.pydata.org/
```




    <AxesSubplot:xlabel='Rating', ylabel='Title'>




![png](output_34_1.png)



```python
#we can see that the movies by christopher nolan are frequently top rated
```


```python
#now, we will check the relation between ratings and revenue. as revenue is considered the most important aspect of a movie.
sns.scatterplot(x='Rating',y='Revenue (Millions)',data=df_k)
```




    <AxesSubplot:xlabel='Rating', ylabel='Revenue (Millions)'>




![png](output_36_1.png)



```python
# it is concluded that rating affects revenue. 
```


```python
# let's predict the genre of the movie
g=df_k['Genre'].value_counts().idxmax()
g
```




    'Action,Adventure,Sci-Fi'




```python
#it is clear that genre of the movie shoud be action revolving arround a storyline based on science fiction.
```


```python
df_k[df_k.Genre.str.contains('Action,Adventure,Sci-Fi')].shape
```




    (50, 12)




```python
#50 movies are made under the category of action, scie-fi, adventure.
```


```python
sns.barplot(x='Runtime (Minutes)',y='Metascore',data=h_r,hue='Rating')
```




    <AxesSubplot:xlabel='Runtime (Minutes)', ylabel='Metascore'>




![png](output_42_1.png)



```python
 #metascore is effectively high if the movie runtime is about 110 minutes, also rating is high for the same.
```

## Data Preparation



***
Questions to consider:
* Were there variables you dropped or created?
* yes, dropped column named'originot title'
* How did you address missing values or outliers?
* analyzed the data, there were no outliers and missing data
* Why are these choices appropriate given the data and the business problem?
* Thses choices provides the data in seriess of mast occurence and camparisons to predict the attributes for the movie.

## Data Modeling

***
Questions to consider:
* How did you analyze or model the data?
* we previewed the datasets and cheked the values of mean, median mode, columns,shapes etc. then we sorted and merged the datasets to create a model and performed functions on that.
* we also used one more data set from kaggle to do some extra work.
* Why are these choices appropriate given the data and the business problem?
* as all the data sets are about movies, so, there were some attributes common in each set, like title, votes etc. merging the datasets allowed to seea bigger picture, which then helped to predict the trend.

## Evaluation
Evaluate how well your work solves the stated business problem.

***
Questions to consider:
* How do you interpret the results?
* results shos the comparisons, frequent occurence of strings in top rated movies with high revenue. this will help to understand the algorithm of a successfull movie.
* How well does your model fit your data? How much better is this than your baseline model?
* the model have all the colmns set and clean. there is no coumn whihc is not useful and the dataset contains the values of all initial sets.
* How confident are you that your results would generalize beyond the data you have?
* I can take the risk to produce this movie, and still sleep well.
* How confident are you that this model would benefit the business if put into use?
* Microsoft will be bigger than MARVEL STUDIOS.
***

## Conclusions

***
Questions to consider:
* What would you recommend the business do as a result of this work?
* Microsoft should make a movie which revolves arround technology and science fiction, with the storyline of adventure and action mixed.
* What are some reasons why your analysis might not fully solve the business problem?
* entertainment industry is been always a chanllenge. audience is unpredictable. Eventhough, the pridictions are done in perfact way, there is still 0.00001 percent chance to face failure.
* What else could you do in the future to improve this project?
* as these datasets have information much old, I woould use a realtime dataset.
***
